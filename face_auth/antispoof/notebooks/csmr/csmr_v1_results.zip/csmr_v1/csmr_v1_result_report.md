# CSMR-PAD v1 pilot result

## A. Hypothesis
Controlled FFT amplitude attenuation during training probes which spectral band most reduces the correct Real-versus-Attack margin. One gain is shared across the three band views of each sample. The training loss uses the most harmful view and penalizes only a drop in the label-aligned margin. Inference keeps the Stage 1 spatial network and ordinary RGB preprocessing.

## B. Protocol
Frozen CelebA micro-Train/Val: 5,000/2,000; seed 42; architecture `MobileNetV3-Small-GAP-576-256-BN-HSwish-Dropout02-128-3-v1`. LCC-FASD is external development. Checkpoint and threshold selected on micro-Val only. Stage 1 summary supplies a metric reference; its checkpoint was never loaded.
Stage 0 resource hashes: `{"celeba_bbox_cache_sha256": "ee176ce62c62d64c922fefde38a260356b0fd35da696ebf0553db3e92932fd1a", "lcc_cache_sha256": "277993f3c8ac436c7fc4f852892a64299b6ccb23063b1774e055a4317c29f78c", "lcc_candidate_n": 3766, "lcc_detector_sha256": "5e4447f50245bbd7966bd6c0fa52938c61474a04ec7def48753668a9d8b4ea3a", "lcc_manifest_sha256": "af864ab57bf26af800ceac46c00d9724c8c60f5d0c63037394a1d8708a35abe5", "lcc_valid_face_n": 3762, "lcc_valid_path_fingerprint_sha256": "cf74fb7d56cad5164b984c50697d0cd6674662a196469ccf7c3f90b66d720a8b", "micro_manifest_sha256": "7c1eed4abaab7ee193758ea4bf4a0c36b98e43b5fb8d84c5c0e7d424607a0aa3", "micro_train_keys_fingerprint": "9ce47155516d265dc9d6eccbc0ea4105684afe7c9f87ae00cb53789830a53caf", "micro_val_keys_fingerprint": "51f43df4b705e6b36d551eb59e5daf1d3a8852d6cb1e8ea4e654524a75f82274", "parent_e1_manifest_sha256": "7799486ebcae0babe09e061579ac05db7c1dc61e10746be0755bcddc10b2df9e", "parent_e1_train_fingerprint": "4ecbcee78758366dd454c0e446444f6c74c82ac5c4d1c937730382b34d4e25f8", "parent_e1_val_fingerprint": "4560d12efe0bb840c0584a38bda12097e2048f3066d89177cda62f8d931edf91"}`.

## C. Baseline vs CSMR
| Model | Val ACER | Val AUC | LCC APCER | LCC BPCER | LCC HTER | LCC AUC |
|---|---:|---:|---:|---:|---:|---:|
| Stage 1 | 0.0211 | 0.9973 | 0.3661 | 0.3265 | 0.3463 | 0.6938 |
| CSMR v1 | 0.0222 | 0.9971 | 0.2487 | 0.3933 | 0.3210 | 0.7256 |

## D. Deltas (CSMR minus Stage 1)
Percentage points: Val ACER: +0.11 pp, Val AUC: -0.02 pp, LCC APCER: -11.74 pp, LCC BPCER: +6.68 pp, LCC HTER: -2.53 pp, LCC AUC: +3.18 pp.

## E. CSMR diagnostics
Final epoch 6: LOW/MID/HIGH worst-band fractions = 0.197/0.352/0.451; harmful fraction = 0.651; mean harmful margin drop = 0.8797302376513255.

## F. Screening verdict
**STRONG_SIGNAL** (pilot heuristic, not a significance test).

## G. Interpretation
One seed and an external-development stress set support method screening only. Threshold-dependent LCC HTER and threshold-independent AUC must be read together. No held-out target test or paper-level claim is implied.

## H. Recommended next step
Confirm on a larger frozen development run and independent seeds; later compare a generic-consistency ablation.
