# MiniFASNetV2 backbone-transfer benchmark

## Objective
Does frozen CSMR-v1 add value to a paired PAD-pretrained MiniFASNetV2 benchmark?

## Provenance and loading
Source SHA `e498c4ec5e1ddfaba62b941a126c19d65aa564999f3309661fe43ee8bf38acd7`; official checkpoint SHA `a5eb02e1843f19b5386b953cc4c9f011c3f985d0ee2bb9819eea9a142099bec0`. Loaded 333 compatible pretrained keys; skipped `prob.weight` only and initialized a fresh 3-class classifier.

## Input and paired initialization
Stage-0 face bbox coordinates, official 2.7 crop geometry, direct 80×80 BGR, float [0,1], no MNV3 normalization. Both runs began at SHA `318dbe2a0fa2c80cc36d4f881aa3967b226255af71a45049529daa5430b93adc`. Train/Val remain frozen 5K/2K from seed42 manifest; training RNG seed 100.

## Vanilla result
Best epoch 10; locked Val threshold -0.324079.

## CSMR result
Best epoch 3; locked Val threshold -2.236379.

## Val/LCC paired comparison
| Metric | Vanilla | CSMR | Delta (CSMR - Vanilla) |
|---|---:|---:|---:|
| Val ACER | 0.016909 | 0.021691 | +0.004782 |
| Val AUC | 0.998290 | 0.996634 | -0.001657 |
| LCC APCER | 0.518233 | 0.495405 | -0.022828 |
| LCC BPCER | 0.118252 | 0.079692 | -0.038560 |
| LCC HTER | 0.318242 | 0.287548 | -0.030694 |
| LCC AUC | 0.819484 | 0.846264 | +0.026779 |

## CSMR diagnostics
Final epoch LOW/MID/HIGH worst-view fractions: 0.124/0.101/0.775; harmful fraction 0.438; mean harmful margin drop 0.7933110461720372; mean gain 0.775; mean clip fraction 0.0123.

## Transfer verdict
**TRANSFER_STRONG** — pre-declared development descriptor, not statistical significance. No CSMR parameter is adjusted from LCC.

## Test-2000 recovery
Recovered the exact previously opened 2,000 keys using the original seed 4242 and three-class stratification; ordered SHA `df3416273c3e7d8bf0caa3b010454ee73236211e034ec12bfb481f056fe237b8`. Rebuilt E1 SCRFD bbox cache SHA `7c4e5b1d326fbf7781c7d049923d557f0e0c298837e32d9ffc614136ecbe0d68` with {'VALID': 1983, 'FALLBACK_DET_FAIL': 14, 'FALLBACK_SUSPICIOUS': 3}; detector SHA `5e4447f50245bbd7966bd6c0fa52938c61474a04ec7def48753668a9d8b4ea3a`. This is a fixed opened descriptive benchmark, not a new independent confirmation. Both models use their locked Val thresholds and MiniFASNet 2.7 crop.

| Metric | Vanilla | CSMR | Delta (CSMR - Vanilla) |
|---|---:|---:|---:|
| Test APCER | 0.361763 | 0.405117 | +0.043355 |
| Test BPCER | 0.030354 | 0.021922 | -0.008432 |
| Test ACER | 0.196058 | 0.213520 | +0.017461 |
| Test AUC | 0.937166 | 0.935649 | -0.001516 |

## Interpretation and limitations
This experiment isolates the incremental effect of frozen CSMR-v1 within MiniFASNetV2. It does not isolate MiniFASNet architecture from its PAD-specific pretrained initialization. MNV3-S used ImageNet pretraining, so absolute backbone metrics also reflect crop/input and pretraining differences. One paired seed and LCC external-development evidence do not establish architecture-independent generalization.

## Recommended next experiment
Replicate the fixed paired comparison with independent seeds and the same protocol.
